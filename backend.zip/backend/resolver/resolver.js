const potsModel=require('../model/model');

const resolver={
    pots:()=>{
        return potsModel.find({});
    },

    addPot:(args)=>{
        let pot= new potsModel({
            name:args.name,
            price:args.price,
            description:args.description,
            product_details:args.product_details,
            image:args.image,
            stock:args.stock
        });

        pot.save();
        return pot;
    }
}

module.exports=resolver;