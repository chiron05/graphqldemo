const mongoose=require('mongoose');

const PotsSchema= new mongoose.Schema({
    name:{
        type: String,
        required:true
    },
    price:{
        type:String
    },
    description:{
        type:String,
        required:true
    },
    product_details:{
        type:String
    },
    image:{
        type:String,
        required:true
    },
    stock:{
        type:String,
        required:true
    }
});

module.exports= new mongoose.model('pots',PotsSchema);