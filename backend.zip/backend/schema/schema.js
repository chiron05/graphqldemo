const {buildSchema} = require('graphql');

const PotsSchema=buildSchema(`

    type Query{
        pots:[pot]
    }


    type Mutation{
        he(name:String!,price: String!, description:String!,product_details:String,image:String,stock:String):pot
    }
    


    type pot{
        name:String,
        price:String,
        description:String,
        product_details:String,
        image:String,
        stock:String

    }
`);

module.exports=PotsSchema;