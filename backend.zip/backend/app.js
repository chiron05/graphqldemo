const express=require('express');
const app=express();
const mongoose=require('mongoose');
const {graphqlHTTP}=require('express-graphql');
const PotsSchema=require('../backend/schema/schema');
const resolver=require('../backend/resolver/resolver');
require('dotenv').config();
const {ApolloServer} =require('apollo-server'); 

const DATABASE_URL=process.env.DATABASE_URL;

//DB connections
mongoose.connect("mongodb+srv://sarthak:sunnaik05@cluster0.llq2n.mongodb.net/Graphql?retryWrites=true&w=majority",{
    useNewUrlParser:true,
    useUnifiedTopology:true,
   
}).then(()=>{
    console.log(`DB CONNECTED`);
}).catch((err)=>{
    console.log(err);
    console.log(`DB NOT CONNECTED`);
});




//setting up graphql server for my application
app.use('/graphql',graphqlHTTP({
    schema:PotsSchema,
    graphiql:true,
    rootValue:resolver
}));


app.listen(4000,()=>{
    console.log(`server on port 4000`);
})